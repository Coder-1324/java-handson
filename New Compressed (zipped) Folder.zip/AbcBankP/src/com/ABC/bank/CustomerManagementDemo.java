package com.ABC.bank;

public class CustomerManagementDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 CustomerManagementSystem system = new CustomerManagementSystem();

	        Customer customer1 = new Customer(1, "ABC", "john@example.com", 1000.0, true);
	        Customer customer2 = new Customer(2, "XYZ", "alice@example.com", 500.0, true);
	        Customer customer3 = new Customer(3, "Ram", "bob@example.com", 200.0, false);

	        system.addCustomer(customer1);
	        system.addCustomer(customer2);
	        system.addCustomer(customer3);

	        // Illustrating functionalities
	        System.out.println("Customer Search:");
	        Customer foundCustomer = system.searchCustomer(2);
	        if (foundCustomer != null) {
	            System.out.println("Customer found: " + foundCustomer.getName());
	        } else 
	            System.out.println("Customer not found.");
	        

	        System.out.println("List of Customers with Credit Permit:");
	        system.listAllCustomers();

	        System.out.println("Withdraw from Customer 1: " + system.withdraw(1, 200));
	        System.out.println("Withdraw from Customer 2: " + system.withdraw(2, 700));

	        System.out.println("\nDelete Customer 1 with 0 balance: " + system.deleteCustomer(1));
	        System.out.println("Delete Customer 2 with 0 balance: " + system.deleteCustomer(2));
	        System.out.println("Delete Customer 3 with 0 balance: " + system.deleteCustomer(3));

	}

}
