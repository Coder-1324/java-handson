package com.ABC.bank;
import java.util.ArrayList;

public class CustomerManagementSystem {
	 private ArrayList<Customer> customerArrayList;

	    public CustomerManagementSystem() {
	        customerArrayList = new ArrayList<>();
	    }

	    public Customer searchCustomer(long customerId) {
	        for (Customer customer : customerArrayList) {
	            if (customer.getCustomerId() == customerId) {
	                return customer;
	            }
	        }
	        return null;
	    }

	    public void listAllCustomers() {
	        for (Customer customer : customerArrayList) {
	            if (customer.isCreditPermit()) {
	                System.out.println("Customer ID: " + customer.getCustomerId());
	                System.out.println("Name: " + customer.getName());
	                System.out.println("Email: " + customer.getEmail());
	                System.out.println("Balance: Rs. " + customer.getBalance());
	                System.out.println("Credit Permit: " + customer.isCreditPermit());
	                System.out.println();
	            }
	        }
	    }

	    public double withdraw(long customerId, double amount) {
	        for (Customer customer : customerArrayList) {
	            if (customer.getCustomerId() == customerId) {
	                if (customer.getBalance() >= amount) {
	                    customer.setBalance(customer.getBalance() - amount);
	                    return customer.getBalance();
	                } else 
	                    return customer.getBalance();
	                
	            }
	        }
	        return -1.00;
	    }

	    public boolean deleteCustomer(long customerId) {
	        for (Customer customer : customerArrayList) {
	            if (customer.getCustomerId() == customerId) {
	                if (customer.getBalance() == 0) {
	                    customerArrayList.remove(customer);
	                    return true;
	                } else 
	                    return false;
	                
	            }
	        }
	        return false;
	    }

	    public void addCustomer(Customer customer) {
	        customerArrayList.add(customer);
	    }

}
