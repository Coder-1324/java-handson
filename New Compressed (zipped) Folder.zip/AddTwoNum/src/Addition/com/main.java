package Addition.com;
import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enetr num 1 :");
		
		int num1 = sc.nextInt();
		System.out.println("Enter Num2 :");
		int num2= sc.nextInt();
		
		int sum = addNumber(num1,num2);
		System.out.println( "the sum of these Numebers" +   sum);
		
		
		
		
		

	}
	public static int addNumber(int a,int b) {
		return a+b;
	}

}
