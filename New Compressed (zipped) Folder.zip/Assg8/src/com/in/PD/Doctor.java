package com.in.PD;

public class Doctor extends Person {
	String D_dsg;
	int D_sal;
	
	Doctor(String n,int a,String d,int s){
		super(n, a);
		this.D_dsg=d;
		this.D_sal=s;
		
	}
	void display() {
		super.display();
		System.out.println("Doctor Designation"+ D_dsg+"Doctot salary  "+D_sal);
	}

}
