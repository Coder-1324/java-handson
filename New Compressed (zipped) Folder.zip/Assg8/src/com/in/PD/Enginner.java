package com.in.PD;

public class Enginner  extends Person{
    int E_Id;
    Enginner(String n,int a,int i){
    	super(n,a);
    	this.E_Id=i;
    }
    void display() {
    	System.out.println("Engineer id = "+E_Id);
    }
}
