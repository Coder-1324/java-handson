package com.in.PD;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person p = new Person("Ram  ",  22);
		p.display();
		
		Doctor d = new Doctor("Dev  ",27,"Surgeon  " ,60000);
		d.display();
		
		Enginner e = new Enginner("ABC  ",24,11);
		d.display();

	}

}
