package com.in.PD;

public class Person {
	String name;
	int age;
	
	Person(String n, int a){
		this.name=n;
		this.age=a;
		
	}
	void display() {
		System.out.println("Name  "+name+"Age  "+age);
	}

}
