package com.AB.Class;

public abstract class Employee {
	private String name;
    private int employeeId;
    private double grossSalary;

    public Employee(String name, int employeeId, double grossSalary) {
        this.name = name;
        this.employeeId = employeeId;
        this.grossSalary = grossSalary;
    }

    // Abstract method for calculating net salary
    public abstract double calculateNetSalary();

    // Abstract method for displaying information
    public abstract void displayInfo();

    public String getName() {
        return name;
    }

    public int getEmployeeId() {
        return employeeId;
    }

    public double getGrossSalary() {
        return grossSalary;
    }

}
