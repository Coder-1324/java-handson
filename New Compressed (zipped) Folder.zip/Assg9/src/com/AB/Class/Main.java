package com.AB.Class;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Manager manager = new Manager("Ram", 101, 50000.0, 10000.0);
        manager.displayInfo();

	}

}
