package com.AB.Class;

public class Manager extends Employee {
	private double allowance;

    public Manager(String name, int employeeId, double grossSalary, double allowance) {
        super(name, employeeId, grossSalary);
        this.allowance = allowance;
    }

    @Override
    public double calculateNetSalary() {
        return getGrossSalary() + allowance;
    }

    @Override
    public void displayInfo() {
        System.out.println("Manager Information:");
        System.out.println("Name: " + getName());
        System.out.println("Employee ID: " + getEmployeeId());
        System.out.println("Gross Salary: Rs. " + getGrossSalary());
        System.out.println("Allowance: Rs. " + allowance);
        System.out.println("Net Salary: Rs. " + calculateNetSalary());
    }

}
