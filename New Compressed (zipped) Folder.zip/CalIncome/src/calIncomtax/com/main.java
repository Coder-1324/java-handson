package calIncomtax.com;
import java.util.Scanner;

public class main {
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enetr  the employee income  in Rs. ");
		int income =sc.nextInt();
		
		
		double tax = calculateIncometax(income);
		
		System.out.println("Incometax in rs " +tax);
		
		
	}
	public static double calculateIncometax(int income) {
		double tax = 0;
		if(income<=50000) {
			tax= 0.0;
		}
		else if(income<=60000) {
			tax=(income-50000)*0.10;
		}
		else if (income<=150000) {
			tax=10000+(income-60000)* 0.20;
		}
		else {
			tax=10000+18000+(income-150000)*0.30;
		}
		return tax;
		
	}

	}


