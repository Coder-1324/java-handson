package com.fac;

import java.util.*;
import java.util.stream.LongStream;
public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		System.out.println("Enetrr a number: ");
		int num= sc.nextInt();
		int fc = inputefactorial(num);
		
		System.out.println(fc);
		

	}
	public static int inputefactorial(int num) {
		if(num<0) {
			 System.out.println("Factorial is not defined for negative numbers.");
		}
		return (int) LongStream.range(1, num).reduce(1, (x,y) -> x * y);
	}

}
