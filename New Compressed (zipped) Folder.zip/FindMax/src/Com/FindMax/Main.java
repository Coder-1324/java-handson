package Com.FindMax;


public class Main {

	public static void main(String[] args) {
		
		
		if(args.length==0) {
			System.out.println("provide input");
			return;
		}
		int mx =Integer.parseInt(args[0]);
		for(int i=1; i<args.length;i++) {
			if(Integer.parseInt(args[i])>mx)
				mx=Integer.parseInt(args[i]);
		}
		System.out.println("Max is"+ mx);

	}

}
