package com.thread;

public class HelloHiThread {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Thread helloThread = new Thread(new  helloRun());
		Thread HiThread = new Thread(new HiRun());
		
		helloThread.start();
        HiThread.start();
	}

}
