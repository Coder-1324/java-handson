package com.thread;

public class helloRun implements Runnable {

	@Override
	public void run() {
		for(int i=0;i<=5; i++) {
			System.out.println("HELLO");
			try{
				Thread.sleep(1000);
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		
	}
	

}
