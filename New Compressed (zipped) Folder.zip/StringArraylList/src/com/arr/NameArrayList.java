package com.arr;

import java.util.ArrayList;
import java.util.*;

public class NameArrayList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner(System.in);
		
		ArrayList<String> Names = new ArrayList<>();
		
		System.out.println("Enter Number of name: ");
		int numNames = sc.nextInt();
	    sc.nextLine();	
	    
	    for(int i=0;i<=numNames; i++) {
	    	System.out.println("Enter Name :"+ i+ ": ");
	    	String name = sc.nextLine();
	    	Names.add(name);
	    }
		
	    System.out.println("Names in the Array List :");
	    for(String name1:Names) {
	    	System.out.println(name1);
	    }
	    sc.close();
		
		
		

	}

}
