package calSalcom.sal;

class Persion{
	String name =null;
	int age =0;
	
public Persion(String n,int a) {
	this.name=n;
	this.age=a;
}
void display() {
	System.out.println("Name" +name+ "age" +age);
}
}
class doctor extends Persion{
	String dg=null;
	int dSal=0;
	doctor(String n, int a, String d, int s){
		super(n,a);
		this.dg=d;
		this.dSal=0;
	}
	
	void display() {
		super.display();
		System.out.println("doc dsg" +dg+ "doc sal" + dSal); 
	}
}
 
class Eng extends Persion{
	int eng_id=0;
	public Eng(String n, int a, int i) {
		super(n,a);
		this.eng_id=i;
	}
	void display() {
		super.display();
		System.out.println("Enterneer id "+ eng_id);
	}
	
}

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		Persion p1 = new Persion("Nikhil",24);
		p1.display();
		
		doctor d1 = new doctor("ram",23,"card", 6000);
		d1.display();
		
		Eng E1 = new Eng("dev",11,20000);
		E1.display();

	}

}
