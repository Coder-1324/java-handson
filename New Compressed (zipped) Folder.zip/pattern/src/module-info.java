/**
 * 
 */
/**
 * 
 */
module pattern {
}