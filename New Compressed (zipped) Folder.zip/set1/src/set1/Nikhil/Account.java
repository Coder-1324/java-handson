package set1.Nikhil;

public class Account {
	
	private  long acNo;
	private  String customername;
	 private String accType;
	 private double balance; 
	private String address;
	 private String email;
	 
	public Account(long acNo, String customername, String accType, double balance, String address, String email) {
		super();
		this.acNo = acNo;
		this.customername = customername;
		this.accType = accType;
		this.balance = balance;
		this.address = address;
		this.email = email;
	}
	public long getAcNo() {
		return acNo;
	}
	public void setAcNo(long acNo) {
		this.acNo = acNo;
	}
	public String getCustomername() {
		return customername;
	}
	public void setCustomername(String customername) {
		this.customername = customername;
	}
	public String getAccType() {
		return accType;
	}
	public void setAccType(String accType) {
		this.accType = accType;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	
	

}
