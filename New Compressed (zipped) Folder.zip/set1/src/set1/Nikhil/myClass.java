package set1.Nikhil;

import java.util.Scanner;

public class myClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		
		Account[] account = new Account[5];
		
		for(int i =0; i<5; i++) {
			System.out.println("Enter the deatils for the Accounts"+ (i+1)+":");
			System.out.println("Account Number : ");
			long accNo = sc.nextLong();
			sc.nextLine();
			System.out.println("Customer Name");
			String customerName = sc.nextLine();
			System.out.println("Enter  the Account type (saving/current): ");
			String accuntType=sc.nextLine();
			System.out.println("Enter the balance");
			double balance = sc.nextDouble();
			sc.nextLine();
			System.out.println("Address");
			String address= sc.nextLine();
			System.out.println("Email");
			String email= sc.nextLine();
			
			account[i]= new Account(accNo,customerName,accuntType,balance,address,email); 
		}
		
		System.out.println("Enter account Number for withdrowal");
		long accountNo = sc.nextLong();
		System.out.println("Enter  amount  for withdroal");
		double amount = sc.nextDouble();
		
		double newBalance = withdrawFromAccount(account, accountNo, amount);
		
		if (newBalance== -1.0) {
			System.out.println("Enoghf balance");
			
		}
		else {
			System.out.println("availbale abalnce  in rs :"+ newBalance);
		}
		Account[] accountsBelowMinBalance= accountsBelowMinimumBalance(account);
		if (accountsBelowMinBalance !=null) {
			System.out.println("Accounts below minimum balance:");
			for(Account account1: accountsBelowMinBalance) {
				System.out.println("Account number"+ account1.getAcNo());
			}
		}else {
			System.out.println("All the accounts are maintaining the minimum balance.");
		}
		

	}
	
	public static Account[] accountsBelowMinimumBalance(Account[] accounts){
		double minBalanceSaving=500.0;
		double minBalanceCurrents=1000.0;
		
		Account[] belowMinBalanceAccounts = new Account[accounts.length];
		int count =0;
		for(Account account:accounts) {
			if(account.getAccType().equalsIgnoreCase("Saving") && account.getBalance()<minBalanceSaving)
			{
				belowMinBalanceAccounts[count]=account;
				count ++;
			}
			else if (account.getAccType().equalsIgnoreCase("Current") && account.getBalance()<minBalanceCurrents)
			{
				belowMinBalanceAccounts[count]=account;
				count++;
				
			}
			
		}
		  if (count ==0) {
			  return null;
			  
		  }
		  else {
			  Account[] result= new Account[count];
	            System.arraycopy(belowMinBalanceAccounts, 0, result, 0, count);
	            return result ;
 
			  
		  }
		
	}
	public static double withdrawFromAccount(Account[] accounts,long accountNo, double amount) {
		for(Account account :accounts) {
			if(account.getAcNo()==accountNo){
				if(account.getBalance()>=amount) {
					account.setBalance(account.getBalance()-amount);
					return account.getBalance();
				}
				else return -1;
			}
		}
		return -1;
		
	}

	private static long acccountNo() {
		// TODO Auto-generated method stub
		return 0;
	}
	

}
