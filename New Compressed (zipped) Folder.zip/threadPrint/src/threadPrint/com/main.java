package threadPrint.com;

class helloRunnable implements Runnable{
	 @Override
	 public void run() {
		 for(int i=0;i<5;i++) {
			 System.out.println("HELLO");
			 try {
				 Thread.sleep(1000);
			 }catch(Exception e){
				 e.printStackTrace();
			 }
		 }
	 }
	
}

class hiRunnable implements Runnable{
	public void  run() {
		for(int i=0;i<5;i++) {
		System.out.println("Hi");
		try {
			Thread.sleep(1000);
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
 }
}

public class main {
	public static void main(String[] args) {
		Thread HelloThread= new Thread(new helloRunnable());
		Thread HiThread = new Thread(new hiRunnable());
		
		HelloThread.start();
		HiThread.start();
		
	}

}
